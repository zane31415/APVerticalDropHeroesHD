﻿using Microsoft.CodeAnalysis.CSharp.Scripting;
using Microsoft.CodeAnalysis.Scripting;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.CommandLine;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Underanalyzer.Decompiler;
using UndertaleModLib;
using UndertaleModLib.Compiler;
using UndertaleModLib.Decompiler;
using UndertaleModLib.Models;
using UndertaleModLib.Project;
using UndertaleModLib.Scripting;
using UndertaleModLib.Util;
using static UndertaleModLib.UndertaleReader;

namespace UndertaleModCli;

/// <summary>
/// Main CLI Program
/// </summary>
public partial class Program : IScriptInterface
{
    #region Properties

    // taken from the Linux programmer manual:
    /// <summary>
    /// Value that should be returned on a successful operation.
    /// </summary>
    private const int EXIT_SUCCESS = 0;

    /// <summary>
    /// Value that should be returned on a failed operation.
    /// </summary>
    private const int EXIT_FAILURE = 1;

    /// <summary>
    /// Value that determines if the current Program is running in interactive mode.
    /// </summary>
    private bool IsInteractive { get; }

    /// <summary>
    /// Value that determines if the current Program is running in verbose mode.
    /// </summary>
    private bool Verbose { get; }

    /// <summary>
    /// File path or directory path that determines an output for the current Program.
    /// </summary>
    private FileSystemInfo Output { get; }

    /// <summary>
    /// Constant, used to indicate that the user wants to replace everything in a replace command.
    /// </summary>
    private const string UMT_REPLACE_ALL = "UMT_REPLACE_ALL";

    /// <summary>
    /// Constant, used to indicate that the user wants to dump everything in a dump command
    /// </summary>
    private const string UMT_DUMP_ALL = "UMT_DUMP_ALL";

    //TODO: document these, these are intertwined with inherited updating methods
    private int progressValue;
    private Task updater;
    private CancellationTokenSource cTokenSource;
    private CancellationToken cToken;

    private string savedMsg, savedStatus;
    private double savedValue, savedValueMax;

    /// <summary>
    /// The ScriptOptions, only used for <see cref="CSharpScript"/>, aka running C# code.
    /// </summary>
    private ScriptOptions CliScriptOptions { get; }

    /// <summary>
    /// Determines if actions should show a "this is finished" text. Gets set by <see cref="SetFinishedMessage"/>.
    /// </summary>
    private bool FinishedMessageEnabled { get; set; }

    /// <summary>
    /// Indicates if the script was cancelled by user action (via ScriptException).
    /// </summary>
    private bool ScriptCancelled { get; set; }

    /// <summary>
    /// Buffer for piped input, allowing seamless transition to interactive input when exhausted.
    /// </summary>
    private static Queue<string> _pipedInputBuffer;

    /// <summary>
    /// Reader for direct console input when piped input is exhausted.
    /// </summary>
    private static StreamReader _consoleReader;

    #endregion

    /// <summary>
    /// Main entrypoint for Cli
    /// </summary>
    /// <param name="args">Arguments passed on to program.</param>
    /// <returns>Result code of the program.</returns>
    public static int Main(string[] args)
    {
        // Give a friendly message when not running from an actual console, on Windows... (and when no arguments are passed in)
        if (OperatingSystem.IsWindows() && args.Length == 0 && Console.GetCursorPosition() == (0, 0))
        {
            Console.WriteLine("UndertaleModCli is meant to be executed from a command line terminal/console.\nDid you mean to download the GUI version of UndertaleModTool instead?\n\n(Press any key to dismiss this message.)");
            Console.ReadKey();
            return EXIT_FAILURE;
        }

        // Pre-buffer any piped input so we can track when to switch to interactive mode
        if (Console.IsInputRedirected)
        {
            _pipedInputBuffer = new Queue<string>();
            string line;
            while ((line = Console.ReadLine()) != null)
            {
                _pipedInputBuffer.Enqueue(line);
            }
        }

        Option<bool> verboseOption = new("-v", "--verbose") { Description = "Detailed logs" };

        Argument<FileInfo> dataFileArgument = new("datafile")
        {
            Description = "Path to the data.win/.ios/.droid/.unx file"
        };

        // Setup new command
        Option<FileInfo> newOutputOption = new("-o", "--output") { DefaultValueFactory = _ => new NewOptions().Output };
        Option<bool> newOverwriteOption = new("-f", "--overwrite") { Description = "Overwrite destination file if it already exists" };
        Option<bool> newStdoutOption = new("-", "--stdout") { Description = "Write new data content to stdout" };
        Command newCommand = new("new", "Generates a blank data file")
        {
            newOutputOption,
            newOverwriteOption,
            newStdoutOption, // "-" is often used in *nix land as a replacement for stdout
            verboseOption
        };
        newCommand.SetAction(parseResult =>
        {
            return New(new NewOptions()
            {
                Output = parseResult.GetValue(newOutputOption),
                Overwrite = parseResult.GetValue(newOverwriteOption),
                Stdout = parseResult.GetValue(newStdoutOption),
                Verbose = parseResult.GetValue(verboseOption)
            });
        });

        // Setup load command
        Option<FileInfo[]> scriptRunnerOption = new("-s", "--scripts") { Description = "Scripts to apply to the <datafile>. Ex. a.csx b.csx" };
        Option<FileInfo> loadOutputOption = new("-o", "--output") { Description = "Where to save the modified data file" };
        Option<string> loadLineOption = new("-l", "--line") { Description = "Run C# string. Runs AFTER everything else" };
        Option<bool> loadInteractiveOption = new("-i", "--interactive") { Description = "Interactive menu launch" };
        Command loadCommand = new("load", "Load a data file and perform actions on it")
        {
            dataFileArgument,
            scriptRunnerOption,
            verboseOption,
            // TODO: why no force overwrite here, but needed for new?
            loadOutputOption,
            loadLineOption,
            // TODO: make interactive another Command
            loadInteractiveOption
        };
        loadCommand.SetAction(parseResult =>
        {
            return Load(new LoadOptions()
            {
                Datafile = parseResult.GetValue(dataFileArgument),
                Scripts = parseResult.GetValue(scriptRunnerOption),
                Line = parseResult.GetValue(loadLineOption),
                Output = parseResult.GetValue(loadOutputOption),
                Interactive = parseResult.GetValue(loadInteractiveOption),
                Verbose = parseResult.GetValue(verboseOption)
            });
        });

        // Setup info command
        Command infoCommand = new("info", "Show basic info about the game data file") { dataFileArgument, verboseOption };
        infoCommand.SetAction(parseResult =>
        {
            return Info(new InfoOptions()
            {
                Datafile = parseResult.GetValue(dataFileArgument),
                Verbose = parseResult.GetValue(verboseOption)
            });
        });

        // Setup dump command
        Option<DirectoryInfo> dumpOutputOption = new("-o", "--output") { Description = "Where to dump data file properties to. Will default to path of the data file" };
        Option<string[]> dumpCodeOption = new("-c", "--code")
        {
            Description = $"The code files to dump. Ex. gml_Script_init_map gml_Script_reset_map. Specify '{UMT_DUMP_ALL}' to dump all code entries"
        };
        Option<bool> dumpStringsOption = new("-s", "--strings") { Description = "Whether to dump all strings" };
        Option<bool> dumpTexturesOption = new("-t", "--textures") { Description = "Whether to dump all embedded textures" };
        Option<bool> dumpSpritesOption = new("--sprites") { Description = "Whether to dump all sprites" };
        Command dumpCommand = new("dump", "Dump certain properties about the game data file")
        {
            dataFileArgument,
            verboseOption,
            dumpOutputOption,
            dumpCodeOption,
            dumpStringsOption,
            dumpTexturesOption,
            dumpSpritesOption
        };
        dumpCommand.SetAction(parseResult =>
        {
            return Dump(new DumpOptions()
            {
                Datafile = parseResult.GetValue(dataFileArgument),
                Verbose = parseResult.GetValue(verboseOption),
                Output = parseResult.GetValue(dumpOutputOption),
                Code = parseResult.GetValue(dumpCodeOption),
                Strings = parseResult.GetValue(dumpStringsOption),
                Textures = parseResult.GetValue(dumpTexturesOption),
                Sprites = parseResult.GetValue(dumpSpritesOption)
            });
        });

        // Setup replace command
        Option<FileInfo> replaceOutputOption = new("-o", "--output") { Description = "Where to save the modified data file" };
        Option<string[]> replaceCodeOption = new("-c", "--code")
        {
            Description = $"Which code files to replace with which file. Ex. 'gml_Script_init_map=./newCode.gml'. It is possible to replace everything by using '{UMT_REPLACE_ALL}'"
        };
        Option<string[]> replaceTexturesOption = new("-t", "--textures")
        {
            Description = $"Which embedded texture entry to replace with which file. Ex. 'Texture 0=./newTexture.png'. It is possible to replace everything by using '{UMT_REPLACE_ALL}'"
        };
        Command replaceCommand = new("replace", "Replace certain properties in the game data file")
        {
            dataFileArgument,
            verboseOption,
            replaceOutputOption,
            replaceCodeOption,
            replaceTexturesOption
        };
        replaceCommand.SetAction(parseResult =>
        {
            return Replace(new ReplaceOptions()
            {
                Datafile = parseResult.GetValue(dataFileArgument),
                Verbose = parseResult.GetValue(verboseOption),
                Output = parseResult.GetValue(replaceOutputOption),
                Code = parseResult.GetValue(replaceCodeOption),
                Textures = parseResult.GetValue(replaceTexturesOption)
            });
        });

        // Setup project command
        Argument<FileInfo> projectBuildFileArgument = new("file")
        {
            Description = "Path to the UndertaleModTool project.json file"
        };
        Option<FileInfo> projectBuildSourceOption = new("-s", "--source") { Description = "Source data file", Required = true };
        Option<FileInfo> projectBuildDestinationOption = new("-d", "--destination") { Description = "Destination data file", Required = true };

        Command projectBuildCommand = new("build", "Build a project")
        {
            projectBuildFileArgument,
            verboseOption,
            projectBuildSourceOption,
            projectBuildDestinationOption
        };

        projectBuildCommand.SetAction(parseResult =>
        {
            return BuildProject(new ProjectBuildOptions()
            {
                ProjectFile = parseResult.GetValue(projectBuildFileArgument),
                Verbose = parseResult.GetValue(verboseOption),
                Source = parseResult.GetValue(projectBuildSourceOption),
                Destination = parseResult.GetValue(projectBuildDestinationOption)
            });
        });

        Command projectCommand = new("project", "Subcommands that deal with projects")
        {
            projectBuildCommand
        };

        // Merge everything together
        RootCommand rootCommand =
        [
            newCommand,
            loadCommand,
            infoCommand,
            dumpCommand,
            replaceCommand,
            projectCommand
        ];
        rootCommand.Description = "CLI tool for modding, decompiling and unpacking Undertale (and other GameMaker games)!";
        ParseResult parseResult = rootCommand.Parse(args);
        return parseResult.Invoke();
    }

    public Program(FileInfo datafile, FileInfo[] scripts, FileInfo output, bool verbose = false, bool interactive = false)
    {
        this.Verbose = verbose;
        IsInteractive = interactive;
        Console.InputEncoding = Encoding.UTF8;
        Console.OutputEncoding = Console.InputEncoding;


        Console.WriteLine($"Trying to load file: '{datafile.FullName}'");

        this.FilePath = datafile.FullName;
        this.ExePath = Environment.CurrentDirectory;
        this.Output = output;

        this.Data = ReadDataFile(datafile, WarningHandler, this.Verbose ? MessageHandler : DummyHandler);

        FinishedMessageEnabled = true;
        this.CliScriptOptions = ScriptingUtil.CreateDefaultScriptOptions()
                                             .AddReferences(GetType().GetTypeInfo().Assembly,
                                                            typeof(JsonConvert).GetTypeInfo().Assembly);
    }

    public Program(FileInfo datafile, bool verbose, DirectoryInfo output = null)
    {
        if (datafile == null) throw new ArgumentNullException(nameof(datafile));

        Console.WriteLine($"Trying to load file: '{datafile.FullName}'");
        this.Verbose = verbose;
        this.Data = ReadDataFile(datafile, verbose ? WarningHandler : null, verbose ? MessageHandler : null);
        this.Output = output ?? new DirectoryInfo(datafile.DirectoryName);

        if (this.Verbose)
            Console.WriteLine("Output directory has been set to " + this.Output.FullName);
    }

    /// <summary>
    /// Method that gets executed on the "new" command
    /// </summary>
    /// <param name="options">The arguments that have been provided with the "new" command</param>
    /// <returns><see cref="EXIT_SUCCESS"/> and <see cref="EXIT_FAILURE"/> for being successful and failing respectively</returns>
    private static int New(NewOptions options)
    {
        //TODO: this should probably create a new Program instance, with just the properties that it needs

        UndertaleData data = UndertaleData.CreateNew();

        // If stdout flag is set, write new data to stdout and quit
        if (options.Stdout)
        {
            if (options.Verbose) Console.WriteLine("Attempting to write new Data file to STDOUT...");
            using MemoryStream ms = new MemoryStream();
            UndertaleIO.Write(ms, data);
            Console.OpenStandardOutput().Write(ms.ToArray(), 0, (int)ms.Length);
            Console.Out.Flush();
            if (options.Verbose) Console.WriteLine("Successfully wrote new Data file to STDOUT.");

            return EXIT_SUCCESS;
        }

        // If not STDOUT, write to file instead. Check first if we have permission to overwrite
        if (options.Output.Exists && !options.Overwrite)
        {
            Console.Error.WriteLine($"'{options.Output}' already exists. Pass --overwrite to overwrite");
            return EXIT_FAILURE;
        }

        // We're not writing to STDOUT, and overwrite flag was given, so we write to specified file.
        if (options.Verbose) Console.WriteLine($"Attempting to write new Data file to '{options.Output}'...");
        using FileStream fs = options.Output.OpenWrite();
        UndertaleIO.Write(fs, data);
        if (options.Verbose) Console.WriteLine($"Successfully wrote new Data file to '{options.Output}'.");
        return EXIT_SUCCESS;
    }

    /// <summary>
    /// Method that gets executed on the "load" command
    /// </summary>
    /// <param name="options">The arguments that have been provided with the "load" command</param>
    /// <returns><see cref="EXIT_SUCCESS"/> and <see cref="EXIT_FAILURE"/> for being successful and failing respectively</returns>
    private static int Load(LoadOptions options)
    {
        Program program;

        // Try to load necessary values.
        // This can throw if mandatory arguments are not given, in which case we want to exit cleanly without a stacktrace.
        try
        {
            program = new Program(options.Datafile, options.Scripts, options.Output, options.Verbose, options.Interactive);
        }
        catch (Exception e)
        {
            Console.Error.WriteLine(e.Message);
            return EXIT_FAILURE;
        }

        // If interactive is enabled, launch the menu instead
        if (options.Interactive)
        {
            program.RunInteractiveMenu();
            return EXIT_SUCCESS;
        }

        // If we have any scripts to run, run every one of them
        if (options.Scripts != null)
        {
            foreach (FileInfo script in options.Scripts)
            {
                program.RunCSharpFile(script.FullName);

                // If script execution failed, stop and return failure
                if (!program.ScriptExecutionSuccess)
                {
                    Console.Error.WriteLine($"Script execution failed: {script.FullName}");
                    return EXIT_FAILURE;
                }
            }
        }

        // If line to execute was given, execute it
        if (options.Line != null)
        {
            program.ScriptPath = null;
            program.RunCSharpCode(options.Line);

            // If script execution failed, stop and return failure
            if (!program.ScriptExecutionSuccess)
            {
                Console.Error.WriteLine("Script execution failed");
                return EXIT_FAILURE;
            }
        }

        // If script was cancelled by user, exit successfully without saving
        if (program.ScriptCancelled)
            return EXIT_SUCCESS;

        // If parameter to save file was given, save the data file
        if (options.Output != null)
            program.SaveDataFile(options.Output.FullName);

        return EXIT_SUCCESS;
    }

    /// <summary>
    /// Method that gets executed on the "info" command
    /// </summary>
    /// <param name="options">The arguments that have been provided with the "info" command</param>
    /// <returns><see cref="EXIT_SUCCESS"/> and <see cref="EXIT_FAILURE"/> for being successful and failing respectively</returns>
    private static int Info(InfoOptions options)
    {
        Program program;
        try
        {
            program = new Program(options.Datafile, options.Verbose);
        }
        catch (FileNotFoundException e)
        {
            Console.Error.WriteLine(e.Message);
            return EXIT_FAILURE;
        }

        program.CliQuickInfo();
        return EXIT_SUCCESS;
    }

    /// <summary>
    /// Method that gets executed on the "dump" command
    /// </summary>
    /// <param name="options">The arguments that have been provided with the "dump" command</param>
    /// <returns><see cref="EXIT_SUCCESS"/> and <see cref="EXIT_FAILURE"/> for being successful and failing respectively</returns>
    private static int Dump(DumpOptions options)
    {
        Program program;
        try
        {
            program = new Program(options.Datafile, options.Verbose, options.Output);
        }
        catch (FileNotFoundException e)
        {
            Console.Error.WriteLine(e.Message);
            return EXIT_FAILURE;
        }

        if (program.Data.IsYYC())
        {
            Console.WriteLine("The game was made with YYC (YoYo Compiler), which means that the code was compiled into the executable. " +
                              "There is thus no code to dump. Exiting.");
            return EXIT_SUCCESS;
        }

        // If user provided code to dump, dump code
        if ((options.Code?.Length > 0) && (program.Data.Code?.Count > 0))
        {
            GlobalDecompileContext globalDecompileContext = new(program.Data);
            IDecompileSettings decompilerSettings = program.Data.ToolInfo.DecompilerSettings;

            // If user wanted to dump everything, do that, otherwise only dump what user provided
            if (options.Code.Contains(UMT_DUMP_ALL))
            {
                int totalCores = Environment.ProcessorCount;
                int outerLimit = Math.Max(1, totalCores / 4);
                Parallel.ForEach(program.Data.Code, new ParallelOptions { MaxDegreeOfParallelism = outerLimit }, code =>
                {
                    if (code.ParentEntry is not null)
                    {
                        return;
                    }
                    program.DumpCodeEntry(code, globalDecompileContext, decompilerSettings);
                });
            }
            else
            {
                foreach (string code in options.Code)
                {
                    program.DumpCodeEntry(code, globalDecompileContext, decompilerSettings);
                }
            }
        }

        // If user wanted to dump strings, dump all of them in a text file
        if (options.Strings)
            program.DumpAllStrings();

        // If user wanted to dump embedded textures, dump all of them
        if (options.Textures)
            program.DumpAllTextures();

        // If user wanted to dump sprites, dump all of them
        if (options.Sprites)
            program.DumpAllSprites().Wait();

        return EXIT_SUCCESS;
    }

    /// <summary>
    /// Method that gets executed on the "replace" command
    /// </summary>
    /// <param name="options">The arguments that have been provided with the "replace" command</param>
    /// <returns><see cref="EXIT_SUCCESS"/> and <see cref="EXIT_FAILURE"/> for being successful and failing respectively</returns>
    private static int Replace(ReplaceOptions options)
    {
        Program program;
        try
        {
            program = new Program(options.Datafile, null, options.Output, options.Verbose);
        }
        catch (FileNotFoundException e)
        {
            Console.Error.WriteLine(e.Message);
            return EXIT_FAILURE;
        }

        // If user provided code to replace, replace them
        if ((options.Code?.Length > 0) && (program.Data.Code.Count > 0))
        {
            // get the values and put them into a dictionary for ease of use
            Dictionary<string, FileInfo> codeDict = new Dictionary<string, FileInfo>();
            foreach (string code in options.Code)
            {
                string[] splitText = code.Split('=');

                if (splitText.Length != 2)
                {
                    Console.Error.WriteLine($"{code} is malformed! Should be of format 'name_of_code=./newCode.gml' instead!");
                    return EXIT_FAILURE;
                }

                codeDict.Add(splitText[0], new FileInfo(splitText[1]));
            }

            // If user wants to replace all, we'll be handling it differently. Replace every file from the provided directory
            if (codeDict.ContainsKey(UMT_REPLACE_ALL))
            {
                string directory = codeDict[UMT_REPLACE_ALL].FullName;
                foreach (FileInfo file in new DirectoryInfo(directory).GetFiles())
                    program.ReplaceCodeEntryWithFile(Path.GetFileNameWithoutExtension(file.Name), file);
            }
            // Otherwise, just replace every file which was given
            else
            {
                foreach (KeyValuePair<string, FileInfo> keyValue in codeDict)
                    program.ReplaceCodeEntryWithFile(keyValue.Key, keyValue.Value);
            }
        }

        // If user provided texture to replace, replace them
        if (options.Textures?.Length > 0)
        {
            // get the values and put them into a dictionary for ease of use
            Dictionary<string, FileInfo> textureDict = new Dictionary<string, FileInfo>();
            foreach (string texture in options.Textures)
            {
                string[] splitText = texture.Split('=');

                if (splitText.Length != 2)
                {
                    Console.Error.WriteLine($"{texture} is malformed! Should be of format 'Name=./new.png' instead!");
                    return EXIT_FAILURE;
                }

                textureDict.Add(splitText[0], new FileInfo(splitText[1]));
            }

            // If user wants to replace all, we'll be handling it differently. Replace every file from the provided directory
            if (textureDict.ContainsKey(UMT_REPLACE_ALL))
            {
                string directory = textureDict[UMT_REPLACE_ALL].FullName;
                foreach (FileInfo file in new DirectoryInfo(directory).GetFiles())
                    program.ReplaceTextureWithFile(Path.GetFileNameWithoutExtension(file.Name), file);
            }
            // Otherwise, just replace every file which was given
            else
            {
                foreach ((string key, FileInfo value) in textureDict)
                    program.ReplaceTextureWithFile(key, value);
            }
        }

        // If parameter to save file was given, save the data file
        if (options.Output != null)
            program.SaveDataFile(options.Output.FullName);

        return EXIT_SUCCESS;
    }

    private static int BuildProject(ProjectBuildOptions options)
    {
        try
        {
            ArgumentNullException.ThrowIfNull(options.ProjectFile);
            ArgumentNullException.ThrowIfNull(options.Source);
            ArgumentNullException.ThrowIfNull(options.Destination);
        }
        catch (Exception e)
        {
            Console.Error.WriteLine(e.Message);
            return EXIT_FAILURE;
        }

        // Load source
        Program program;
        try
        {
            program = new Program(options.Source, options.Verbose);
        }
        catch (FileNotFoundException e)
        {
            Console.Error.WriteLine(e.Message);
            return EXIT_FAILURE;
        }

        program.FilePath = options.Destination.FullName;

        // Load project
        ProjectContext newProjectContext;
        try
        {
            if (program.Verbose)
                Console.WriteLine($"Loading project file '{options.ProjectFile.FullName}'");

            newProjectContext = ProjectContext.CreateWithDataFilePaths(options.Source.FullName, options.Destination.FullName, options.ProjectFile.FullName);

            if (program.Verbose)
                Console.WriteLine($"Importing project into source data file");

            newProjectContext.Import(program.Data);
        }
        catch (ProjectException e)
        {
            Console.Error.WriteLine($"Failed to load project: {e.Message}");
            return EXIT_FAILURE;
        }
        catch (Exception e)
        {
            Console.Error.WriteLine($"Error occurred when loading project:\n{e}");
            return EXIT_FAILURE;
        }

        program.Project = newProjectContext;

        // Save destination data file
        if (program.Verbose)
            Console.WriteLine($"Saving to destination data file");

        program.SaveDataFile(options.Destination.FullName);

        return EXIT_SUCCESS;
    }

    /// <summary>
    /// Runs the interactive menu indefinitely until user quits out of it.
    /// </summary>
    private void RunInteractiveMenu()
    {
        while (true)
        {
            Console.WriteLine("Interactive Menu:");
            Console.WriteLine("1 - Run script.");
            Console.WriteLine("2 - Run C# string.");
            Console.WriteLine("3 - Save and overwrite.");
            Console.WriteLine("4 - Save to different place.");
            Console.WriteLine("5 - Display quick info.");
            //TODO: add dumping and replacing options
            Console.WriteLine("6 - Quit without saving.");

            Console.Write("Input, please: ");
            ConsoleKey k = Console.ReadKey().Key;
            Console.WriteLine();

            switch (k)
            {
                // 1 - run script
                case ConsoleKey.NumPad1:
                case ConsoleKey.D1:
                    {
                        Console.Write("File path (you can drag and drop)? ");
                        string path = RemoveQuotes(Console.ReadLine());
                        Console.WriteLine("Trying to run script {0}", path);
                        try
                        {
                            RunCSharpFile(path);
                        }
                        catch (Exception)
                        {
                            // ignored
                        }

                        break;
                    }

                // 2 - run c# string
                case ConsoleKey.NumPad2:
                case ConsoleKey.D2:
                    {
                        Console.Write("C# code line? ");
                        string line = Console.ReadLine();
                        ScriptPath = null;
                        RunCSharpCode(line);
                        break;
                    }

                // Save and overwrite data file
                case ConsoleKey.NumPad3:
                case ConsoleKey.D3:
                    {
                        SaveDataFile(FilePath);
                        break;
                    }

                // Save data file to different path
                case ConsoleKey.NumPad4:
                case ConsoleKey.D4:
                    {
                        Console.Write("Where to save? ");
                        string path = RemoveQuotes(Console.ReadLine());
                        SaveDataFile(path);
                        break;
                    }

                // Print out Quick Info
                case ConsoleKey.NumPad5:
                case ConsoleKey.D5:
                    {
                        CliQuickInfo();
                        break;
                    }

                // Quit
                case ConsoleKey.NumPad6:
                case ConsoleKey.D6:
                    {
                        Console.WriteLine("Are you SURE? You can press 'n' and save before the changes are gone forever!!!");
                        Console.WriteLine("(Y/N)? ");
                        bool isInputYes = Console.ReadKey(false).Key == ConsoleKey.Y;
                        Console.WriteLine();
                        if (isInputYes) return;

                        break;
                    }

                default:
                    {
                        Console.WriteLine("Unknown input. Try using the upper line of digits on your keyboard.");
                        break;
                    }
            }
        }
    }

    /// <summary>
    /// Prints some basic info about the loaded data file.
    /// </summary>
    private void CliQuickInfo()
    {
        Console.WriteLine("Quick Information:");
        Console.WriteLine("Project Name - {0}", Data.GeneralInfo.Name);
        Console.WriteLine("Is GMS2 - {0}", Data.IsGameMaker2());
        Console.WriteLine("Is YYC - {0}", Data.IsYYC());
        Console.WriteLine("Bytecode version - {0}", Data.GeneralInfo.BytecodeVersion);
        Console.WriteLine("Configuration name - {0}", Data.GeneralInfo.Config);

        Console.WriteLine($"{Data.Sounds.Count} Sounds, {Data.Sprites.Count} Sprites, {Data.Backgrounds.Count} Backgrounds");
        Console.WriteLine($"{Data.Paths.Count} Paths, {Data.Scripts.Count} Scripts, {Data.Shaders.Count} Shaders");
        Console.WriteLine($"{Data.Fonts.Count} Fonts, {Data.Timelines.Count} Timelines, {Data.GameObjects.Count} Game Objects");
        Console.WriteLine($"{Data.Rooms.Count} Rooms, {Data.Extensions.Count} Extensions, {Data.TexturePageItems.Count} Texture Page Items");
        if (!Data.IsYYC())
        {
            Console.WriteLine($"{Data.Code.Count} Code Entries, {Data.Variables.Count} Variables, {Data.Functions.Count} Functions");
            var codeLocalsInfo = Data.CodeLocals is not null ? $"{Data.CodeLocals.Count} Code locals, " : "";
            Console.WriteLine($"{codeLocalsInfo}{Data.Strings.Count} Strings, {Data.EmbeddedTextures.Count} Embedded Textures");
        }
        else
        {
            Console.WriteLine("Unknown amount of Code entries and Code locals");
        }

        Console.WriteLine($"{Data.Strings.Count} Strings");
        Console.WriteLine($"{Data.EmbeddedTextures.Count} Embedded Textures");
        Console.WriteLine($"{Data.EmbeddedAudio.Count} Embedded Audio");

        if (IsInteractive) Pause();
    }

    /// <summary>
    /// Dumps a code entry from a data file.
    /// </summary>
    /// <param name="codeEntryName">The code entry name that should get dumped</param>
    /// <param name="context">Decompile context to use when dumping</param>
    /// <param name="settings">Settings to use for the decompiler</param>
    private void DumpCodeEntry(string codeEntryName, GlobalDecompileContext context, IDecompileSettings settings)
    {
        UndertaleCode code = Data.Code.ByName(codeEntryName);

        if (code == null)
        {
            Console.Error.WriteLine($"Data file does not contain a code entry named {codeEntryName}!");
            return;
        }

        DumpCodeEntry(code, context, settings);
    }

    /// <summary>
    /// Dumps a code entry from a data file.
    /// </summary>
    /// <param name="code">The code entry that should get dumped</param>
    /// <param name="context">Decompile context to use when dumping</param>
    /// <param name="settings">Settings to use for the decompiler</param>
    private void DumpCodeEntry(UndertaleCode code, GlobalDecompileContext context, IDecompileSettings settings)
    {
        string directory = Path.Join(Output.FullName, "CodeEntries");

        Directory.CreateDirectory(directory);

        if (Verbose)
            Console.WriteLine($"Dumping {code.Name?.Content}");

        string dest = Paths.TryJoinVerifyWithinDirectory(directory, $"{code.Name?.Content}.gml");
        if (dest is null)
        {
            Console.Error.WriteLine($"Failed to export code entry with name {code.Name?.Content}");
            return;
        }
        File.WriteAllText(dest, GetDecompiledText(code, context, settings));
    }

    /// <summary>
    /// Dumps all strings in a data file.
    /// </summary>
    private void DumpAllStrings()
    {
        string directory = Output.FullName;

        Directory.CreateDirectory(directory);

        StringBuilder combinedText = new StringBuilder();
        foreach (UndertaleString dataString in Data.Strings)
        {
            if (Verbose)
                Console.WriteLine($"Added {dataString.Content}");
            combinedText.Append($"{dataString.Content}\n");
        }

        if (Verbose)
            Console.WriteLine("Writing all strings to disk");
        File.WriteAllText(Path.Join(directory, "strings.txt"), combinedText.ToString());
    }

    /// <summary>
    /// Dumps all embedded textures in a data file.
    /// </summary>
    private void DumpAllTextures()
    {
        string directory = Path.Join(Output.FullName, "EmbeddedTextures");

        Directory.CreateDirectory(directory);

        foreach (UndertaleEmbeddedTexture texture in Data.EmbeddedTextures)
        {
            if (Verbose)
                Console.WriteLine($"Dumping {texture.Name}");
            if (texture.TextureData.Image is not GMImage image)
            {
                Console.WriteLine($"{texture.Name} has no image assigned, skipping");
                continue;
            }
            string dest = Paths.TryJoinVerifyWithinDirectory(directory, $"{texture.Name.Content}.png");
            if (dest is null)
            {
                Console.Error.WriteLine($"Failed to export texture with name {texture.Name.Content}");
                return;
            }
            using FileStream fs = new(dest, FileMode.Create);
            texture.TextureData.Image.SavePng(fs);
        }
    }

    /// <summary>
    /// Helper class for exporting texture page items, e.g. for dumping sprites.
    /// </summary>
    private class TextureToExport
    {
        public UndertaleTexturePageItem PageItem { get; set; }
        public UndertaleEmbeddedTexture Page => PageItem.TexturePage;
        public string FileExportLocation { get; set; }

        public TextureToExport(UndertaleTexturePageItem pageItem, string fileExportLocation) => (PageItem, FileExportLocation) = (pageItem, fileExportLocation);
    }

    /// <summary>
    /// Dumps all sprites in a data file.
    /// </summary>
    private async Task DumpAllSprites()
    {
        string directory = Path.Join(Output.FullName, "Sprites");

        Directory.CreateDirectory(directory);

        // As of writing, this code is copied over from the ExportAllSprites.csx script

        // TODO: make this configurable, but this is a reasonable default
        bool padded = true;

        ConcurrentDictionary<string, ConcurrentBag<TextureToExport>> texturesToExport = new();

        Console.WriteLine("Fetching sprite textures...");
        await Task.Run(() => Parallel.ForEach(Data.Sprites, spr =>
        {
            FetchTexturesFromSprite(spr);
        }));

        Console.WriteLine("Exporting sprite textures...");
        await Task.Run(() => ExportTextures());

        void FetchTexturesFromSprite(UndertaleSprite sprite)
        {
            if (sprite is not { SSpriteType: UndertaleSprite.SpriteType.Normal, Textures.Count: > 0 })
            {
                // IncrementProgressParallel();
                return;
            }

            for (int i = 0; i < sprite.Textures.Count; i++)
            {
                if (sprite.Textures[i]?.Texture is not null)
                {
                    UndertaleTexturePageItem pageItem = sprite.Textures[i].Texture;

                    var bag = texturesToExport.GetOrAdd(pageItem.TexturePage.Name.Content, _ => new ConcurrentBag<TextureToExport>());
                    bag.Add(new TextureToExport(pageItem, Paths.JoinVerifyWithinDirectory(directory, $"{sprite.Name.Content}_{i}.png")));
                }
            }
            // IncrementProgressParallel();
        }

        void ExportTextures()
        {
            int totalCores = Environment.ProcessorCount;
            int outerLimit = Math.Max(1, totalCores / 4);
            Parallel.ForEach(texturesToExport, new ParallelOptions { MaxDegreeOfParallelism = outerLimit }, kvp =>
            {
                using TextureWorker localWorker = new();

                foreach (TextureToExport tte in kvp.Value)
                {
                    if (Verbose)
                        Console.WriteLine($"Dumping {tte.PageItem.Name}");
                    localWorker.ExportAsPNG(tte.PageItem, tte.FileExportLocation, null, padded);
                }
                // IncrementProgressParallel();
            });
        }
    }

    /// <summary>
    /// Replaces a code entry with text from another file.
    /// </summary>
    /// <param name="codeEntry">The code entry to replace</param>
    /// <param name="fileToReplace">File path which should replace the code entry.</param>
    private void ReplaceCodeEntryWithFile(string codeEntry, FileInfo fileToReplace)
    {
        if (Verbose)
            Console.WriteLine("Replacing " + codeEntry);

        // Read source code from file
        string gmlCode = File.ReadAllText(fileToReplace.FullName);

        // Link code to object events manually only if collision events are used
        CompileResult result = CompileResult.UnsuccessfulResult;
        bool manualLink = false;
        const string objectPrefix = "gml_Object_";
        if (codeEntry.StartsWith(objectPrefix, StringComparison.Ordinal))
        {
            // Parse object event. First, find positions of last two underscores in name.
            int lastUnderscore = codeEntry.LastIndexOf('_');
            int secondLastUnderscore = codeEntry.LastIndexOf('_', lastUnderscore - 1);
            if (lastUnderscore <= 0 || secondLastUnderscore <= 0)
            {
                Console.Error.WriteLine($"Failed to parse object code entry name: \"{codeEntry}\"");
                return;
            }

            // Extract object name, event type, and event subtype
            ReadOnlySpan<char> objectName = codeEntry.AsSpan(new Range(objectPrefix.Length, secondLastUnderscore));
            ReadOnlySpan<char> eventType = codeEntry.AsSpan(new Range(secondLastUnderscore + 1, lastUnderscore));
            if (!uint.TryParse(codeEntry.AsSpan(lastUnderscore + 1), out uint eventSubtype))
            {
                // No number at the end of the name; parse it out as best as possible (may technically be ambiguous sometimes...).
                // It should be a collision event, though.
                manualLink = true;
                ReadOnlySpan<char> nameAfterPrefix = codeEntry.AsSpan(objectPrefix.Length);
                const string collisionSeparator = "_Collision_";
                int collisionSeparatorPos = nameAfterPrefix.LastIndexOf(collisionSeparator);
                if (collisionSeparatorPos != -1)
                {
                    // Split out the actual object name and the collision subtype
                    objectName = nameAfterPrefix[0..collisionSeparatorPos];
                    ReadOnlySpan<char> collisionSubtype = nameAfterPrefix[(collisionSeparatorPos + collisionSeparator.Length)..];

                    if (Data.IsVersionAtLeast(2, 3))
                    {
                        // GameMaker 2.3+ uses the object name for the collision subtype
                        int objectIndex = Data.GameObjects.IndexOfName(collisionSubtype);
                        if (objectIndex >= 0)
                        {
                            // Object already exists; use its ID as a subtype
                            eventSubtype = (uint)objectIndex;
                        }
                        else
                        {
                            // Need to create a new object
                            eventSubtype = (uint)Data.GameObjects.Count;
                            Data.GameObjects.Add(new()
                            {
                                Name = Data.Strings.MakeString(collisionSubtype.ToString())
                            });
                        }
                    }
                    else
                    {
                        // Pre-2.3 GMS2 versions use GUIDs... need to resolve it
                        eventSubtype = ReduceCollisionValue(GetCollisionValueFromCodeNameGUID(codeEntry));
                        ReassignGUIDs(collisionSubtype.ToString(), ReduceCollisionValue(GetCollisionValueFromCodeNameGUID(codeEntry)));
                    }
                }
                else
                {
                    Console.Error.WriteLine($"Failed to parse event type and subtype for \"{codeEntry}\".");
                    return;
                }
            }
            else if (eventType.SequenceEqual("Collision"))
            {
                // Handle collision events with object ID at the end of the name
                manualLink = true;
                if (eventSubtype >= Data.GameObjects.Count)
                {
                    if (ScriptQuestion($"Object of ID {eventSubtype} was not found.\nAdd new object? (will be ID {Data.GameObjects.Count})"))
                    {
                        // Create new object at end of game object list
                        eventSubtype = (uint)Data.GameObjects.Count;
                        Data.GameObjects.Add(new()
                        {
                            Name = Data.Strings.MakeString(
                                SimpleTextInput("Enter object name", $"Enter object name for ID {eventSubtype}", "", false))
                        });
                    }
                    else
                    {
                        // It *needs* to have a valid value, make the user specify one
                        eventSubtype = ReduceCollisionValue([uint.MaxValue]);
                    }
                }
            }

            // If manually linking, do so
            if (manualLink)
            {
                // Create new object if necessary
                UndertaleGameObject obj = Data.GameObjects.ByName(objectName);
                if (obj is null)
                {
                    obj = new()
                    {
                        Name = Data.Strings.MakeString(objectName.ToString())
                    };
                    Data.GameObjects.Add(obj);
                }

                // Link to object's event with a blank code entry
                UndertaleCode manualCode = UndertaleCode.CreateEmptyEntry(Data, codeEntry);
                CodeImportGroup.LinkEvent(obj, manualCode, EventType.Collision, eventSubtype, MainThreadAction);

                // Perform code import using manual code entry
                CodeImportGroup group = new(Data);
                group.QueueReplace(manualCode, gmlCode);
                result = group.Import();
            }
        }

        // When not manually linking, just let a code import group do it during importing
        if (!manualLink)
        {
            CodeImportGroup group = new(Data);
            group.QueueReplace(codeEntry, gmlCode);
            result = group.Import();
        }

        // Error if import failed
        if (!result.Successful)
        {
            Console.Error.WriteLine("Code import unsuccessful:\n" + result.PrintAllErrors(false));
        }
    }

    /// <summary>
    /// Replaces an embedded texture with contents from another file.
    /// </summary>
    /// <param name="textureEntry">Embedded texture to replace</param>
    /// <param name="fileToReplace">File path which should replace the embedded texture.</param>
    private void ReplaceTextureWithFile(string textureEntry, FileInfo fileToReplace)
    {
        UndertaleEmbeddedTexture texture = Data.EmbeddedTextures.ByName(textureEntry);

        if (texture == null)
        {
            Console.Error.WriteLine($"Data file does not contain an embedded texture named {textureEntry}!");
            return;
        }

        if (Verbose)
            Console.WriteLine("Replacing " + textureEntry);

        texture.TextureData.Image = GMImage.FromPng(File.ReadAllBytes(fileToReplace.FullName));
    }

    /// <summary>
    /// Evaluates and executes the contents of a file as C# Code.
    /// </summary>
    /// <param name="path">Path to file which contents to interpret as C# code</param>
    private void RunCSharpFile(string path)
    {
        string lines;
        try
        {
            lines = File.ReadAllText(path, Encoding.UTF8);
        }
        catch (Exception exc)
        {
            // rethrow as otherwise this will get interpreted as success
            Console.Error.WriteLine(exc.Message);
            throw;
        }

        lines = $"#line 1 \"{path}\"\n" + lines;
        ScriptPath = path;
        RunCSharpCode(lines, ScriptPath);
    }

    /// <summary>
    /// Evaluates and executes given C# code.
    /// </summary>
    /// <param name="code">The C# string to execute</param>
    /// <param name="scriptFile">The path to the script file where <paramref name="code"/> was loaded from.
    /// Leave as null, if it wasn't executed from a script file.</param>
    private void RunCSharpCode(string code, string scriptFile = null)
    {
        if (Verbose)
            Console.WriteLine($"Attempting to execute '1{scriptFile ?? code}'...");

        try
        {
            CSharpScript.EvaluateAsync(code, CliScriptOptions.WithFilePath(scriptFile ?? "").WithFileEncoding(Encoding.UTF8), this, typeof(IScriptInterface)).GetAwaiter().GetResult();
            ScriptExecutionSuccess = true;
            ScriptErrorMessage = "";
        }
        catch (ScriptCancelledException exc) // Script was cancelled by user
        {
            ScriptExecutionSuccess = true;
            ScriptCancelled = true;
            ScriptErrorMessage = "";

            if (FinishedMessageEnabled)
                Console.WriteLine(exc.Message);

            return;
        }
        catch (Exception exc)
        {
            ScriptExecutionSuccess = false;
            ScriptErrorMessage = exc.ToString();
            ScriptErrorType = "Exception";
        }

        if (!FinishedMessageEnabled) return;

        if (ScriptExecutionSuccess)
        {
            if (Verbose)
                Console.WriteLine($"Finished executing '{scriptFile ?? code}'");
        }
        else
        {
            Console.Error.WriteLine(ScriptErrorMessage);
        }
    }

    /// <summary>
    /// Saves the currently loaded <see cref="Data"/> to an output path.
    /// </summary>
    /// <param name="outputPath">The path where to save the data.</param>
    /// <exception cref="IOException">If saving fails</exception>
    private void SaveDataFile(string outputPath)
    {
        if (Verbose)
            Console.WriteLine($"Saving new data file to '{outputPath}'");
        try
        {
            // Save data.win to temp file
            using (FileStream fs = new(outputPath + "temp", FileMode.Create, FileAccess.Write))
            {
                UndertaleIO.Write(fs, Data, MessageHandler);
            }

            // If we're executing this, the saving was successful. So we can replace the new temp file
            // with the older file, if it exists.
            File.Move(outputPath + "temp", outputPath, true);

            if (Verbose)
                Console.WriteLine($"Saved data file to '{outputPath}'");
        }
        catch (Exception e)
        {
            // Delete the temporary file in case we partially wrote it
            if (File.Exists(outputPath + "temp"))
                File.Delete(outputPath + "temp");
            throw new IOException($"Could not save data file: {e.Message}");
        }
    }

    /// <summary>
    /// Read supplied filename and return the data file.
    /// </summary>
    /// <param name="datafile">The datafile to read</param>
    /// <param name="warningHandler">Handler for warnings</param>
    /// <param name="messageHandler">Handler for messages</param>
    /// <returns></returns>
    /// <exception cref="FileNotFoundException">If the data file cannot be found</exception>
    private static UndertaleData ReadDataFile(FileInfo datafile, WarningHandlerDelegate warningHandler = null, MessageHandlerDelegate messageHandler = null)
    {
        try
        {
            using FileStream fs = datafile.OpenRead();
            UndertaleData gmData = UndertaleIO.Read(fs, warningHandler, messageHandler);
            return gmData;
        }
        catch (FileNotFoundException e)
        {
            throw new FileNotFoundException($"Data file '{e.FileName}' does not exist");
        }
    }

    // need this on Windows when drag and dropping files.
    /// <summary>
    /// Trims <c>"</c> or <c>'</c> from the beginning and end of a string.
    /// </summary>
    /// <param name="s"><see cref="String"/> to remove <c>"</c> and/or <c>'</c> from</param>
    /// <returns>A new <see cref="String"/> that can be directly passed onto a FileInfo Constructor</returns>
    //TODO: needs some proper testing on how it behaves on Linux/MacOS and might need to get expanded
    private static string RemoveQuotes(string s)

    {
        return s?.Trim('"', '\'');
    }

    /// <summary>
    /// Reads a line from console, with fallback to interactive input when piped input is exhausted.
    /// </summary>
    /// <returns>The line read from console, or null if no input is available</returns>
    private static string ReadLineWithFallback()
    {
        if (_pipedInputBuffer != null && _pipedInputBuffer.Count > 0)
        {
            string input = _pipedInputBuffer.Dequeue();
            Console.WriteLine(input); // echo piped input to console
            return input;
        }

        if (_consoleReader == null)
        {
            try
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux) || RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                {
                    var fileStream = new FileStream("/dev/tty", FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    _consoleReader = new StreamReader(fileStream, Console.InputEncoding);
                }
                else if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    var fileStream = new FileStream("CONIN$", FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    _consoleReader = new StreamReader(fileStream, Console.InputEncoding);
                }
            }
            catch { }
        }

        return _consoleReader?.ReadLine() ?? Console.ReadLine();
    }

    /// <summary>
    /// Replicated the CMD Pause command. Waits for any key to be pressed before continuing.
    /// </summary>
    private static void Pause()
    {
        Console.WriteLine();
        Console.Write("Press any key to continue . . . ");
        Console.ReadKey(true);
        Console.WriteLine();
    }

    /// <summary>
    /// A simple warning handler that prints warnings to console.
    /// </summary>
    /// <param name="warning">The warning to print</param>
    /// <param name="isImportant">Whether the warning is important (may lead to data corruption)</param>
    private static void WarningHandler(string warning, bool isImportant) => Console.WriteLine($"[WARNING]: {warning}");

    /// <summary>
    /// A simple message handler that prints messages to console.
    /// </summary>
    /// <param name="message">The message to print</param>
    private static void MessageHandler(string message) => Console.WriteLine($"[MESSAGE]: {message}");

    /// <summary>
    /// A dummy handler that does nothing.
    /// </summary>
    /// <param name="message">Not used.</param>
    private static void DummyHandler(string message)
    { }

    //TODO: document these as well
    private void ProgressUpdater()
    {
        DateTime prevTime = default;
        int prevValue = 0;

        while (true)
        {
            if (cToken.IsCancellationRequested)
            {
                if (prevValue >= progressValue) //if reached maximum
                    return;

                if (prevTime == default)
                    prevTime = DateTime.UtcNow;                                       //begin measuring
                else if (DateTime.UtcNow.Subtract(prevTime).TotalMilliseconds >= 500) //timeout - 0.5 seconds
                    return;
            }

            UpdateProgressValue(progressValue);

            prevValue = progressValue;

            Thread.Sleep(100); //10 times per second
        }
    }
}
